! function(t) {
    "use strict";
    var e = function(n, a) {
        this.$element = t(n), this.options = t.extend({}, e.defaults, a)
    };
    e.defaults = {
        transition_delay: 300,
        refresh_speed: 50,
        display_text: "none",
        use_percentage: !0,
        percent_format: function(t) {
            return t + "%"
        },
        amount_format: function(t, e, n) {
            return t + " / " + e
        },
        update: t.noop,
        done: t.noop,
        fail: t.noop
    }, e.prototype.transition = function() {
        var n = this.$element,
            a = n.parent(),
            s = this.$back_text,
            r = this.$front_text,
            i = this.options,
            o = parseInt(n.attr("data-transitiongoal")),
            h = parseInt(n.attr("aria-valuemin")) || 0,
            d = parseInt(n.attr("aria-valuemax")) || 100,
            f = a.hasClass("vertical"),
            p = i.update && "function" == typeof i.update ? i.update : e.defaults.update,
            u = i.done && "function" == typeof i.done ? i.done : e.defaults.done,
            c = i.fail && "function" == typeof i.fail ? i.fail : e.defaults.fail;
        if (isNaN(o)) return void c("data-transitiongoal not set");
        var l = Math.round(100 * (o - h) / (d - h));
        if ("center" === i.display_text && !s && !r) {
            this.$back_text = s = t("<span>").addClass("progressbar-back-text").prependTo(a), this.$front_text = r = t("<span>").addClass("progressbar-front-text").prependTo(n);
            var g;
            f ? (g = a.css("height"), s.css({
                height: g,
                "line-height": g
            }), r.css({
                height: g,
                "line-height": g
            }), t(window).resize(function() {
                g = a.css("height"), s.css({
                    height: g,
                    "line-height": g
                }), r.css({
                    height: g,
                    "line-height": g
                })
            })) : (g = a.css("width"), r.css({
                width: g
            }), t(window).resize(function() {
                g = a.css("width"), r.css({
                    width: g
                })
            }))
        }
        setTimeout(function() {
            var t, e, c, g, _;
            f ? n.css("height", l + "%") : n.css("width", l + "%");
            var x = setInterval(function() {
                f ? (c = n.height(), g = a.height()) : (c = n.width(), g = a.width()), t = Math.round(100 * c / g), e = Math.round(h + c / g * (d - h)), t >= l && (t = l, e = o, u(n), clearInterval(x)), "none" !== i.display_text && (_ = i.use_percentage ? i.percent_format(t) : i.amount_format(e, d, h), "fill" === i.display_text ? n.text(_) : "center" === i.display_text && (s.text(_), r.text(_))), n.attr("aria-valuenow", e), p(t, n)
            }, i.refresh_speed)
        }, i.transition_delay)
    };
    var n = t.fn.progressbar;
    t.fn.progressbar = function(n) {
        return this.each(function() {
            var a = t(this),
                s = a.data("bs.progressbar"),
                r = "object" == typeof n && n;
            s || a.data("bs.progressbar", s = new e(this, r)), s.transition()
        })
    }, t.fn.progressbar.Constructor = e, t.fn.progressbar.noConflict = function() {
        return t.fn.progressbar = n, this
    }
}(window.jQuery);