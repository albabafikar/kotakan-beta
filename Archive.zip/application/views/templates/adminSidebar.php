            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li><a href="<?= $this->adminSite ?>dashboard"><i class="fa fa-home"></i> Beranda</span></a></li>
                  <li><a href="<?= $this->adminSite ?>item"><i class="fa fa-cubes"></i> Kelola Menu</span></a></li>
                  <li><a href="<?= $this->adminSite ?>order"><i class="fa fa-send"></i> Kelola Order</span></a></li>
                  <li><a href="<?= $this->adminSite ?>artikel"><i class="fa fa-file-text-o"></i> Kelola Artikel</span></a></li>
                  <li><a href="<?= $this->adminSite ?>contact"><i class="fa fa-envelope-o"></i> Kelola Kontak</span></a></li>
                  <!-- <li><a href="<?= $this->adminSite ?>category"><i class="fa fa-database"></i> Kelola Kategori</span></a></li>
                  <li><a href="<?= $this->adminSite ?>subcategory"><i class="fa fa-database"></i> Kelola Sub Kategori</span></a></li> -->
                  <!-- <li><a><i class="fa fa-clone"></i>Layouts <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="fixed_sidebar.html">Fixed Sidebar</a></li>
                      <li><a href="fixed_footer.html">Fixed Footer</a></li>
                    </ul>
                  </li> -->
                </ul>
              </div>
            </div>
            <!-- /sidebar menu -->